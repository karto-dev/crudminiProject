package com.product.crudproduct.controller;
import com.product.crudproduct.model.Movie;
import com.product.crudproduct.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
public class MovieController {
    @Autowired
    private MovieService service;
    @GetMapping("/Movie")
    public List<Movie> getallMovies()
    {
        return service.getMovieDetails();
    }
    @GetMapping("/Movie/{id}")
    public Movie getMovie(@PathVariable int id){
        return service.getMovieById(id);
    }
    @PostMapping("/save")
    public Movie add(@RequestBody Movie movie)
    {
        return service.saveMovie(movie);

    }
    @PutMapping ("/update")
    public Movie update(@RequestBody Movie movie)
    {
        return service.updateMovie(movie);

    }
    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable int id)
    {
         service.deleteMovie(id);
         return "Deleted Successfully";
    }
}
