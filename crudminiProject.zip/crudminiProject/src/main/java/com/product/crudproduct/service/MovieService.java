package com.product.crudproduct.service;

import com.product.crudproduct.model.Movie;
import com.product.crudproduct.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class MovieService {
    @Autowired
    private MovieRepository repository;

    public Movie saveMovie(Movie movie)
    {
       return repository.save(movie);
    }

    public List<Movie> getMovieDetails()
    {
        return repository.findAll();
    }
    public Movie getMovieById(int id)
    {
        return repository.findById(id).orElse(null);
    }

    public Movie updateMovie(Movie movie)
    {
        Movie m=repository.findById(movie.getId()).orElse(null);
        m.setMovname(movie.getMovname());
        m.setDirector(movie.getDirector());
        m.setRating(movie.getRating());
        m.setYr(movie.getYr());
        return repository.save(m);

    }
    public String deleteMovie(int id)
    {
        repository.deleteById(id);
        return "Movie deleted";
    }
}
