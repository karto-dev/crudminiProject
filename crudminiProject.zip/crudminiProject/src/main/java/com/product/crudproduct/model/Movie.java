package com.product.crudproduct.model;

import javax.persistence.*;
import jdk.jfr.Enabled;
import lombok.*;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Getter
@Setter
@Table(name="Movie_Table")
public class Movie {
    @Id
    @Column(name="id")
    @GeneratedValue(strategy= GenerationType.SEQUENCE, generator = "id_Sequence")
    @SequenceGenerator(name = "id_Sequence", sequenceName = "ID_SEQ")
    private int id;
    @Column(name="movname")
    private String movname;
    @Column(name="director")
    private String director;
    @Column(name="rating")
    private String rating;
    @Column(name="yr")
    private String yr;

}

