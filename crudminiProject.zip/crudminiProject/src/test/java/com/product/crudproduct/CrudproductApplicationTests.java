package com.product.crudproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudproductApplicationTests {

	@Test
	void contextLoads() {
	}

}
